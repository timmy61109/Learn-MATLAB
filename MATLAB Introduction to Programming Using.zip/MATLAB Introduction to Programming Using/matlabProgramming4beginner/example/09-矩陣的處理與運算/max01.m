x = magic(5);
[colMax, colMaxIndex] = max(x)