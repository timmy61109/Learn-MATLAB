a = [3 4];
x = norm(a, 1)
y = norm(a, 2)
z = norm(a, inf)