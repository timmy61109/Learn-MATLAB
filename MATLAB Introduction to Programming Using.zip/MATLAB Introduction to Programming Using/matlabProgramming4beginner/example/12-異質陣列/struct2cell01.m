student.name = 'Tim';
student.age = 8;
sCell = struct2cell(student)