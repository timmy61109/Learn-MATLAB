[x, y, z] = peaks;  
meshz(x,y,z);  
colormap(zeros(1,3));	                 % �H�¦�e�{       
axis tight;