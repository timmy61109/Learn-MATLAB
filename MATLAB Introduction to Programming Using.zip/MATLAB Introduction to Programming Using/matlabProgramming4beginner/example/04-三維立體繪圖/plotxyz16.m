[X, Y, Z] = peaks;
surf(X, Y, Z, del2(Z));
axis tight;
colormap hot