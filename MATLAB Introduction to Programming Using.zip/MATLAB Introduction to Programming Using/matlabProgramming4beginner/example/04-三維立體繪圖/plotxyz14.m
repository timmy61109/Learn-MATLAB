peaks;
colormap cool; 
colorbar