function func6
global X	% �����ܼƫŧi
X = X + 2;
fprintf('The value of X in "func6" is %g.\n', X); 
