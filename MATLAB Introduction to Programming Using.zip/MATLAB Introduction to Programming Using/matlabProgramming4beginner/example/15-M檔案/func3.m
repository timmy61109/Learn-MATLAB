function [ave1, ave2] = func3(vector1, vector2);
ave1 = sum(vector1)/length(vector1);
ave2 = sum(vector2)/length(vector2);