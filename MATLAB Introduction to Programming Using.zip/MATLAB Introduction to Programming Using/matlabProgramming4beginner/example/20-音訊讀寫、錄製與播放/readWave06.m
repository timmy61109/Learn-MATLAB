[y, fs, nbits, opts]=wavread('flanger.wav');
opts.fmt