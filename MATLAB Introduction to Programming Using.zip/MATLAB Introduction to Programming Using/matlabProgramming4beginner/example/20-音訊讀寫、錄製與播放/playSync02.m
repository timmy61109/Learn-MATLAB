load handel.mat
sound(y, Fs);
sound(y, 1.2*Fs);