load clown.mat
imwrite(X, map, 'myClown.jpg');
!start myClown.jpg