load mandrill.mat
image(X);
colormap(map);
axis image
