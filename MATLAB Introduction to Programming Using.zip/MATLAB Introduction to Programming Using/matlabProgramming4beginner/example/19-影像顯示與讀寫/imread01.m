RGB = imread('simulinkteam.jpg');
image(RGB)