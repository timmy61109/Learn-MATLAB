t = 0:0.1:4*pi;
y = exp(-t/5).*sin(t);
plot(t, y);