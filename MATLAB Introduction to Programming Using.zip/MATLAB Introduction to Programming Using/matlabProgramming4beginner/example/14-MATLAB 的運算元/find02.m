x = magic(3);
[idx1, idx2] = find(x>5)