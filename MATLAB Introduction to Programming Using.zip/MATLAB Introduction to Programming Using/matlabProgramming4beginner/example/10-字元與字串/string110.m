str = 'x = [1 2 3]; y = x.^2';  
eval(str)