x = 1026;
y = dec2hex(x)