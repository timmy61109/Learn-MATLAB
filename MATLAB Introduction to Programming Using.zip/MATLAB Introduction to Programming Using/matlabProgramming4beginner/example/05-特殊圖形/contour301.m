[x, y, z] = peaks;
contour3(x, y, z, 30);
axis tight