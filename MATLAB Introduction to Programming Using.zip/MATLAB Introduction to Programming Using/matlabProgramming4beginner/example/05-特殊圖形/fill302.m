t = (1/16:1/8:1)'*2*pi;
x = sin(t);
y = cos(t);
c = linspace(0, 1, length(t));
fill3(x, y/sqrt(2), y/sqrt(2), c, x/sqrt(2), y, x/sqrt(2), c);
axis tight