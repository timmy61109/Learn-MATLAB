z = peaks;
contourf(z);