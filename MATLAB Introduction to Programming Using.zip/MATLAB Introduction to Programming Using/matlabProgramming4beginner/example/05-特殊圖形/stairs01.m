t = 0:0.4:4*pi;
y = cos(t).*exp(-t/5);
stairs(t, y);