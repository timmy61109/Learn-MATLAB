z = peaks;
[c,handle] = contour(z, 10);
clabel(c, handle);