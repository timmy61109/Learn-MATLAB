y = rand(10,3)*100;
x = 1:10;
area(x, y);
xlabel('Year');
ylabel('Count')