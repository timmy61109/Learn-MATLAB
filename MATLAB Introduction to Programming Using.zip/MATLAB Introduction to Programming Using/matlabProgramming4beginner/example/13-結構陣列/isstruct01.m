s = struct('name', {'Tim', 'Ann'}, 'scores', {[1 3 5 ],[2 4 6]});
isstruct(s)
