student = struct('name', 'Roland', 'scores', [80, 90]);
allFields = fieldnames(student)