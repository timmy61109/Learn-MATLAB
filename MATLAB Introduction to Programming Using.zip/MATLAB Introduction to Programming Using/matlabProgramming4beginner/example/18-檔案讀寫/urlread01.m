contents = urlread('http://www.cs.nthu.edu.tw/~jang');
disp(contents);