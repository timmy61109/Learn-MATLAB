str = num2str([pi, sqrt(2), log10(3)])
retrieved = sscanf(str, '%g')