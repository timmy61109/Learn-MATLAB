[fid, message] = fopen('fopen02.m', 'r');
fprintf('fid = %d\n', fid);
fprintf('message = %s\n', message);
